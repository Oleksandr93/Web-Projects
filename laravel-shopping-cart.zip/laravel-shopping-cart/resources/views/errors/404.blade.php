@extends('master')

@section('content')

    <div class="container">
        <h1>404 Error Page</h1>

        <p>There was an error. Please go back and try again.</p>

    </div> <!-- end container -->

@endsection